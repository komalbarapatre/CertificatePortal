package com.example.certificate.controller;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.certificate.model.*;
import com.example.certificate.model.Employee;
import com.example.certificate.repository.ICertificateRepo;
import com.example.certificate.repository.IEmployeeRepo;
import com.example.certificate.service.EmployeeService;

@Controller
public class CertificateController {

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private IEmployeeRepo iemployeerepo;
	
	@Autowired
	private ICertificateRepo iCertificateRepo;

	
	//Adding data to MongoDB
	@PostMapping("/create")
	public Employee Create(){
		/*
		 * String pattern = "yyyy-MM-dd"; SimpleDateFormat simpleDateFormat = new
		 * SimpleDateFormat(pattern);
		 * 
		 * String sd = simpleDateFormat.format("2018-05-25"); String ed =
		 * simpleDateFormat.format("2018-07-25"); System.out.println(sd);
		 */
       
		//Certificate data
		/*
		 * Certificate c=new Certificate("java","2019-01-25","2019-05-25",10);
		 * Certificate c1=new Certificate("AWS","2018-05-25","2018-07-25",9); return
		 * iCertificateRepo.save(c1);
		 */
		
		//User Data
		
		  EmpCertificate c = new EmpCertificate("java","2019-01-25","2019-05-25","Pending"); 
		  EmpCertificate c1= new EmpCertificate("AWS","2018-05-25","2018-07-25","Completed"); 
		   List l =new ArrayList<>();
		   l.add(c); 
		   l.add(c1);
		   Employee e = new Employee("161020", "Komal", "161017", "User",l);
		  
		  return employeeService.create(e);
		 
		
		
		//admin data
		/*
		 * Employee e = new Employee("161018", "Carel", "161017", "Admin"); return
		 * employeeService.create(e);
		 */
		
	}

	
	//Checking MongoDB data 
	@GetMapping("/get")
	public String get() {
		return employeeService.getAll().toString();
//		return iCertificateRepo.findAll().toString(`);

	}

	@RequestMapping("/")
	public String welcome(@ModelAttribute("t") Employee e) {
		return "welcome";
	}
     
	@RequestMapping("/profile")
	public String profile() {
		return "profile";
	}
     
	
	@RequestMapping("/addCert")
	public String addCert(@ModelAttribute("c") Certificate c) {
		return "AddCert";
	}
	
	@RequestMapping(value="/addCert",method = RequestMethod.POST)
	public String addCertPost(@ModelAttribute("c") Certificate c,ModelMap m) {
		if(iCertificateRepo.findById(c.getCertificateName()).orElse(null) == null) {
			iCertificateRepo.save(c);
			m.addAttribute("msg","Added Successfully!!");
			return "AddCert";
			
		}		
		m.addAttribute("msg","Already exist!!");
		return "AddCert";
	}
    
	@RequestMapping("/assignCert")
	public String assignCert(@ModelAttribute("e") Employee e,ModelMap m,HttpSession session) {
		ArrayList<Certificate> cList=(ArrayList<Certificate>) iCertificateRepo.findAll();
		m.addAttribute("clist", cList);
		System.out.println(cList);
		ArrayList<Employee> eList=(ArrayList<Employee>) iemployeerepo.findAll();
		Employee e1=iemployeerepo.findById(session.getAttribute("empId").toString()).get();
		System.out.println(e1);
		eList.remove(e1);
		m.addAttribute("elist", eList);
		System.out.println(eList);
		return "AssignCert";
	}
	
	@RequestMapping(value="/assignCert",method = RequestMethod.POST)
	public String assignCertPost(@ModelAttribute("e") Employee e,ModelMap m) {

		return "AssignCert";
	}

	
	@RequestMapping("/teammates")
	public String allTeamMember(@ModelAttribute("t") Employee e,HttpSession session, ModelMap m) {
		List<Employee> l = (List<Employee>) iemployeerepo.findAll();
		System.out.println(l.remove(iemployeerepo.findById((String)session.getAttribute("empId")).get()));
		List<Integer> count = new ArrayList<>();
		for (int i = 1; i <= l.size(); i++)
			count.add(i);
		m.addAttribute("count", count);
		m.addAttribute("l", l);
		return "teammates";
	}

	@RequestMapping(value = { "/index" }, method = RequestMethod.POST)
	public String checkLogin(@ModelAttribute("t") Employee e, ModelMap m,@ModelAttribute("c") Certificate c,HttpSession session) {
		System.out.println(e);
		Employee em = iemployeerepo.findById(e.getEmplId()).get();
		// System.out.println("Hiii"+em);
		if (em != null) {
			if (e.getPassword().equals(em.getPassword())) {
				session.setAttribute("empId", em.getEmplId());
				if (em.getRole().equalsIgnoreCase("ADMIN")) {
					 List<Certificate> l = new ArrayList<Certificate>();
					 l=iCertificateRepo.findAll();
					
					// System.out.println(l.remove(0));
					 m.addAttribute("admin", em);
					 m.addAttribute("l", l);

					// System.out.println("admin part:" + l);
					return "index";
				} else {
					m.addAttribute("emp", em);
					// System.out.println("user part:" + em);
					return "employee";
				}
			} else {
				m.addAttribute("msg", "Wrong Credentials.");
				return "welcome";
			}
		} else {
			m.addAttribute("msg", "User doesn't Exist.");
			return "welcome";
		}
	}

	@RequestMapping(value = "/cert/{id}", method = RequestMethod.GET)
	public String getCertificates(@PathVariable("id") String id, ModelMap m) {
		Employee e = employeeService.findById(id);
		m.addAttribute("emp", e);
		return "certificates";
	}
	

	/*
	 * @RequestMapping(value = "/addCert/{id}", method = RequestMethod.GET) public
	 * String getCertificates(@PathVariable("id") String id,
	 * 
	 * @ModelAttribute("t") Certificate c, ModelMap m) { m.addAttribute("empid",
	 * id); return "addCertificate"; }
	 */
     
	//get all the certificates assign to particular employee
	@RequestMapping(value = "/cert/{id}", method = RequestMethod.POST)
	public String updateCertificatesList(@PathVariable("id") String id,
			@ModelAttribute("t") EmpCertificate c, ModelMap m) {
		System.out.println("certificate to add: " + c);
		Employee e = employeeService.Update(id, c);
		System.out.println("Update:  " + e);
		m.addAttribute("emp", e);
		return "certificates";
	}
	
	//get type index
	@RequestMapping(value = { "/index" }, method = RequestMethod.GET)
	public String checkedLogin(@ModelAttribute("t") Employee e, ModelMap m,@ModelAttribute("c") Certificate c,HttpSession session) {
		Employee em = iemployeerepo.findById(session.getAttribute("empId").toString()).get();
		// System.out.println("Hiii"+em);
	
					 List<Certificate> l = new ArrayList<Certificate>();
					 l=iCertificateRepo.findAll();
					// System.out.println(l.remove(0));
					 m.addAttribute("admin", em);
					 m.addAttribute("l", l);
					// System.out.println("admin part:" + l);
					return "index";
				
	}


}
