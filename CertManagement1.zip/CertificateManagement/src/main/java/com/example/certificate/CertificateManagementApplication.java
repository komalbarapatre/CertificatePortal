package com.example.certificate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.session.data.mongo.config.annotation.web.http.EnableMongoHttpSession;
import org.springframework.session.data.mongo.config.annotation.web.reactive.EnableMongoWebSession;

@SpringBootApplication
public class CertificateManagementApplication extends SpringBootServletInitializer{

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		// TODO Auto-generated method stub		
		return builder.sources(CertificateManagementApplication.class);
	}
    

	
	public static void main(String[] args) throws Exception{
		SpringApplication.run(CertificateManagementApplication.class, args);
	}

}
