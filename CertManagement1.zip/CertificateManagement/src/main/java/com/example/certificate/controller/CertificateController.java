package com.example.certificate.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.apache.tomcat.jni.Local;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.certificate.model.*;
import com.example.certificate.model.Employee;
import com.example.certificate.repository.ICertificateRepo;
import com.example.certificate.repository.IEmployeeRepo;
import com.example.certificate.service.CertificateService;
import com.example.certificate.service.EmployeeService;

@Controller
public class CertificateController {

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private CertificateService certificateService;

	// Adding data to MongoDB
	@PostMapping("/create")
	public void Create() {
		/*
		 * String pattern = "yyyy-MM-dd"; SimpleDateFormat simpleDateFormat = new
		 * SimpleDateFormat(pattern);
		 * 
		 * String sd = simpleDateFormat.format("2018-05-25"); String ed =
		 * simpleDateFormat.format("2018-07-25"); System.out.println(sd);
		 */

		// Certificate data

//		 Certificate c=new Certificate("java","2019-01-25","2019-05-25",10);
//		 c.setAssignCount(2);
//		 Certificate c1=new Certificate("AWS","2018-05-25","2018-07-25",9);
//		 c1.setAssignCount(2);
		Certificate c = certificateService.searchById("java");
		Certificate c1 = certificateService.searchById("AWS");
		Certificate c2 = certificateService.searchById("Apache");
		Certificate c3 = certificateService.searchById("Machine Learning & NLP");
		Certificate c4 = certificateService.searchById("Azure");
		c.setStatus("Active");
		c1.setStatus("Active");
		c2.setStatus("Active");
		c3.setStatus("Active");
		c4.setStatus("Active");
		certificateService.create(c);
		certificateService.create(c1);

//		 Certificate c2=new Certificate("Apache","2019-05-02","2019-10-02",2);
//		 c2.setAssignCount(2);
		certificateService.create(c2);
		certificateService.create(c3);
		certificateService.create(c4);

		// User Data

//		EmpCertificate c = new EmpCertificate("java", "2019-01-25", "2019-05-25", "Pending");
//		EmpCertificate c1 = new EmpCertificate("AWS", "2018-05-25", "2018-07-25", "Completed");
//		ArrayList l = new ArrayList<>();
//		l.add(c);
//		l.add(c1);
//		Employee e = new Employee("200000", "Abhijeet", "200000", "User", l);

//		return employeeService.create(e);

		// admin data

		/*
		 * Employee e = new Employee("161018", "Carel", "161017", "Admin"); return
		 * employeeService.create(e);
		 */

	}

	// Checking MongoDB data
	@GetMapping("/get")
	public String get() {
		return employeeService.getAll().toString();
//		return iCertificateRepo.findAll().toString(`);

	}

	@RequestMapping("/")
	public String welcome(@ModelAttribute("t") Employee e) {
		return "welcome";
	}

	@RequestMapping("/profile")
	public String profile() {
		return "profile";
	}

	@RequestMapping("/addCert")
	public String addCert(@ModelAttribute("c") Certificate c) {
		return "AddCert";
	}


	@RequestMapping(value = "/addCert", method = RequestMethod.POST)
	public String addCertPost(@ModelAttribute("c") Certificate c, ModelMap m) throws ParseException  {
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern, new Locale("ENGLISH", "India"));

		String currDate = simpleDateFormat.format(new Date());

		if(c.getStartDate().compareTo(currDate)<0 || c.getEndDate().compareTo(currDate)<0) {m.addAttribute("msg", " Selected date is passed !!");
		return "AddCert";
		}
		if(c.getStartDate().compareTo(c.getEndDate())==0) {
			m.addAttribute("msg", c.getStartDate()+" Start date and End date cannot be same!!");
		return "AddCert";
		}
		LocalDate d1 = LocalDate.parse(c.getStartDate(), DateTimeFormatter.ISO_LOCAL_DATE);
		LocalDate d2 = LocalDate.parse(c.getEndDate(),DateTimeFormatter.ISO_LOCAL_DATE); 
		if(d1.isAfter(d2)) {
			m.addAttribute("msg", c.getStartDate()+" must be before "+ c.getEndDate()+" !!");
		return "AddCert";
		}
		Duration diff = Duration.between(d1.atStartOfDay(), d2.atStartOfDay());
		long diffDays = diff.toDays();
		if(diffDays<=30) {
			m.addAttribute("msg", c.getEndDate()+" Duration must be of 30 days!!");
		return "AddCert";
		}
		if (certificateService.searchById(c.getCertificateName()) == null) {
			c.setStatus("Active");
			certificateService.create(c);
			m.addAttribute("msg", "Added Successfully!!");
			return "AddCert";

		}
		m.addAttribute("msg", "Already exist!!");
		return "AddCert";
	}

	@RequestMapping("/assignCert")
	public String assignCert(@ModelAttribute("e") Employee e, ModelMap m, HttpSession session) {
		ArrayList<Certificate> cList = (ArrayList<Certificate>) certificateService.getAll();
		m.addAttribute("clist", cList);
		System.out.println(cList);
		ArrayList<Employee> eList = (ArrayList<Employee>) employeeService.getAll();
		eList.remove(0);
		Employee e1 = employeeService.searchById(session.getAttribute("empId").toString());
		System.out.println(e1);
		eList.remove(e1);
		m.addAttribute("elist", eList);
		System.out.println(eList);
		return "AssignCert";

//	  ArrayList<ArrayList<EmpCertificate>> lists=new ArrayList<>();
//		ArrayList<EmpCertificate> ecl=new ArrayList<>();
//	    ArrayList<Employee> el=new ArrayList<>();

//		for(Certificate c:cList) {
//			EmpCertificate ec=new EmpCertificate(c.getCertificateName(),c.getStartDate(),c.getEndDate(),"pending");
//			ecl.add(ec);
//			/*Employee emc=new Employee();
//			emc.setCertificates(ecl);
//			el.add(emc);*/
//			
//		}
//		
//		System.out.println(ecl);
//		m.addAttribute("ecl",ecl);
	}

	@RequestMapping(value = "/assignCert", method = RequestMethod.POST)
	public String assignCertPost(@ModelAttribute("e") Employee e, ModelMap m) {
		System.out.println("in Assign Cert: " + e);

		// dynamic input assignment
		ArrayList<Certificate> cList = (ArrayList<Certificate>) certificateService.getAll();
		m.addAttribute("clist", cList);
//   		System.out.println(cList);
		ArrayList<Employee> eList = (ArrayList<Employee>) employeeService.getAll();
		eList.remove(0);
		m.addAttribute("elist", eList);
//   		System.out.println(eList);

		// data posting
		Certificate cert = certificateService.searchById(e.getEmpName());
		System.out.println(cert);
		Employee emp = employeeService.searchById(e.getEmplId());
		System.out.println(emp.getCertificates());

		if (cert.getAssignCount() < cert.getCount()) {
			EmpCertificate ec = new EmpCertificate(cert.getCertificateName(), cert.getStartDate(), cert.getEndDate(),
					"pending");
			boolean duplicate = false;
			for (EmpCertificate fetch : emp.getCertificates()) {
				if (fetch.getCertificateName().equals(cert.getCertificateName())) {
					duplicate = true;
					break;
				}
			}
			if (cert.getStatus().equalsIgnoreCase("Expired")) {
				m.addAttribute("msg", cert.getCertificateName() + " certification have Expired!!");
				return "AssignCert";
			}
			if (duplicate) {
				m.addAttribute("msg", "Already Assigned!!");
				return "AssignCert";
			}
			
			emp.getCertificates().add(ec);
			employeeService.create(emp);
			int assignCount = cert.getAssignCount();
			cert.setAssignCount(assignCount + 1);
			certificateService.create(cert);
			System.out.println(emp.getCertificates());
			m.addAttribute("msg", "Assigned Successfully!!");
			return "AssignCert";
		}
		m.addAttribute("msg", "Cannot Assign. " + cert.getCertificateName() + " certification limit exceed. ");
		return "AssignCert";
	}

	@RequestMapping("/teammates")
	public String allTeamMember(@ModelAttribute("t") Employee e, HttpSession session, ModelMap m) {
		List<Employee> l = (List<Employee>) employeeService.getAll();
		l.remove(0);

		System.out.println(l.remove(employeeService.searchById((String) session.getAttribute("empId"))));
		List<Integer> count = new ArrayList<>();
		for (int i = 1; i <= l.size(); i++)
			count.add(i);
		m.addAttribute("count", count);
		m.addAttribute("l", l);
		return "teammates";
	}

	@RequestMapping(value = { "/index" }, method = RequestMethod.POST)
	public String checkLogin(@ModelAttribute("t") Employee e, ModelMap m, @ModelAttribute("c") Certificate c,
			HttpSession session) {
		System.out.println(e);
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern, new Locale("ENGLISH", "India"));

		String currDate = simpleDateFormat.format(new Date());
		System.out.println(currDate);
		Employee em = employeeService.searchById(e.getEmplId());
		// System.out.println("Hiii"+em);
		if (em != null) {
			if (e.getPassword().equals(em.getPassword())) {
				session.setAttribute("empId", em.getEmplId());
				if (em.getRole().equalsIgnoreCase("ADMIN")) {
					int tcount = 0, acount = 0;
					List<Certificate> l = new ArrayList<Certificate>();
					l = certificateService.getAll();
					for (Certificate i : l) {
						tcount += i.getCount();
						acount += i.getAssignCount();
						if (i.getEndDate().compareTo(currDate) < 0)
							if (i.getStatus().equalsIgnoreCase("Active")) {
								i.setStatus("Expired");
								certificateService.create(i);
							}
						if (i.getStatus().equalsIgnoreCase("Expired")) {
							i.setLapsedCount(i.getCount() - i.getAssignCount());
							certificateService.create(i);
						}
					}

					// lapse certificate

					// System.out.println(l.remove(0));
					m.addAttribute("admin", em);
					m.addAttribute("tcount", tcount);
					m.addAttribute("acount", acount);
					m.addAttribute("dcount", tcount - acount);
					m.addAttribute("l", l);
//					 System.out.println("tcount: "+tcount);

//					 System.out.println("acount: "+acount);
					// System.out.println("admin part:" + l);
					return "index";
				} else {
					int aCount = 0, pCount = 0;
					for (EmpCertificate eCert : em.getCertificates()) {
						aCount++;
						if (eCert.getStatus().equalsIgnoreCase("pending"))
							pCount++;
					}

					m.addAttribute("emp", em);
					m.addAttribute("aCount", aCount);
					m.addAttribute("pCount", pCount);
					m.addAttribute("cCount", aCount - pCount);
					System.out.println("user part:" + em);
					return "employee";
				}
			} else {
				m.addAttribute("msg", "Wrong Credentials.");
				return "welcome";
			}
		} else {
			m.addAttribute("msg", "User doesn't Exist.");
			return "welcome";
		}
	}

	@RequestMapping(value = "/cert/{id}", method = RequestMethod.GET)
	public String getCertificates(@PathVariable("id") String id, ModelMap m) {
		Employee e = employeeService.searchById(id);
		m.addAttribute("emp", e);
		return "certificate";
	}

	/*
	 * @RequestMapping(value = "/addCert/{id}", method = RequestMethod.GET) public
	 * String getCertificates(@PathVariable("id") String id,
	 * 
	 * @ModelAttribute("t") Certificate c, ModelMap m) { m.addAttribute("empid",
	 * id); return "addCertificate"; }
	 */

	// get all the certificates assign to particular employee
	@RequestMapping(value = "/cert/{id}", method = RequestMethod.POST)
	public String updateCertificatesList(@PathVariable("id") String id, @ModelAttribute("t") EmpCertificate c,
			ModelMap m) {
		System.out.println("certificate to add: " + c);
		Employee e = employeeService.Update(id, c);
		System.out.println("Update:  " + e);
		m.addAttribute("emp", e);
		return "certificate";
	}

	// get type index
	@RequestMapping(value = { "/index" }, method = RequestMethod.GET)
	public String checkedLogin(@ModelAttribute("t") Employee e, ModelMap m, @ModelAttribute("c") Certificate c,
			HttpSession session) {
		Employee em = employeeService.searchById(session.getAttribute("empId").toString());
		// System.out.println(l.remove(0));
		if (em.getRole().equalsIgnoreCase("ADMIN")) {
			int tcount = 0, acount = 0;
			List<Certificate> l = new ArrayList<Certificate>();
			l = certificateService.getAll();
			for (Certificate i : l) {
				tcount += i.getCount();
				acount += i.getAssignCount();
			}
			// System.out.println(l.remove(0));
			m.addAttribute("admin", em);
			m.addAttribute("tcount", tcount);
			m.addAttribute("acount", acount);
			m.addAttribute("dcount", tcount - acount);
			m.addAttribute("l", l);
//			 System.out.println("tcount: "+tcount);

//			 System.out.println("acount: "+acount);
			// System.out.println("admin part:" + l);
			return "index";
		} else {
			int aCount = 0, pCount = 0;
			for (EmpCertificate eCert : em.getCertificates()) {
				aCount++;
				if (eCert.getStatus().equalsIgnoreCase("pending"))
					pCount++;
			}

			m.addAttribute("emp", em);
			m.addAttribute("aCount", aCount);
			m.addAttribute("pCount", pCount);
			m.addAttribute("cCount", aCount - pCount);
			System.out.println("user part:" + em);
			return "employee";
		}

	}

	@RequestMapping("/charts")
	String charts(HttpSession session) {
		Employee e = employeeService.searchById((String) session.getAttribute("empId"));
		if (e.getRole().equalsIgnoreCase(("admin")))
			return "AdminCharts";

		return "UserCharts";
	}
}
