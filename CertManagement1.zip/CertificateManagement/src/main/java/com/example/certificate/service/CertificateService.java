package com.example.certificate.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.certificate.model.Certificate;
import com.example.certificate.repository.ICertificateRepo;

@Service
public class CertificateService {

	@Autowired
	ICertificateRepo certificateRepo;
	
	public void create(Certificate e) {
		 certificateRepo.save(e);
	}
	
	
	//get Certificate list
	public List<Certificate> getAll(){
		return (List<Certificate>) certificateRepo.findAll();
	}


	public Certificate searchById(String Id) {
		// TODO Auto-generated method stub
		return certificateRepo.findById(Id).orElse(null);
	}
}
