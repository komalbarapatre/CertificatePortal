package com.example.certificate.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.certificate.model.Certificate;

public interface ICertificateRepo extends MongoRepository<Certificate,String>{

}
