package com.example.certificate.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.certificate.model.Employee;

@Repository
public interface IEmployeeRepo extends CrudRepository<Employee,String>{


}
