package com.example.certificate.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.WebSession;
import org.springframework.web.servlet.ModelAndView;

import com.example.certificate.model.*;
import com.example.certificate.model.Employee;
import com.example.certificate.repository.ICertificateRepo;
import com.example.certificate.repository.IEmployeeRepo;
import com.example.certificate.service.EmployeeService;

@Controller
public class CertificateController {

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private IEmployeeRepo iemployeerepo;
	
	@Autowired
	private ICertificateRepo iCertificateRepo;

	@PostMapping("/create")
	public Employee Create() throws Exception{
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

		String sd1 = simpleDateFormat.format("2018-05-25");
		String sd2 = simpleDateFormat.format("2019-02-25");
		System.out.println(sd1);		

		/*SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		Date yourDate = sdf.parse("2018/06/26");
		Date yourDate1 = sdf.parse("2019/04/26");*/
//		Certificate c=new Certificate("AWS",sd1,sd2,10);
		EmpCertificate c = new EmpCertificate("AWS",sd1,sd2,"completed");
		List l = new ArrayList<>();
		l.add(c);
		Employee e = new Employee("161018", "RAM", "161017", "User",l);
		
		return employeeService.create(e);
//		return iCertificateRepo.save(c);
	}

	@GetMapping("/get")
	public String get() {
		return employeeService.getAll().toString();
//		return iCertificateRepo.findAll().toString(`);

	}

	@RequestMapping("/")
	public String welcome(@ModelAttribute("t") Employee e) {
		return "welcome";
	}

	@RequestMapping("/addCert")
	public String addCert(@ModelAttribute("c") Certificate c,HttpSession session,@ModelAttribute("t") Employee e) {
		String empId=(String)session.getAttribute("info");
		System.out.println("sesion data: "+empId);
		Employee em=iemployeerepo.findById(empId).get();
		e.setEmplId(empId);
		e.setPassword(em.getPassword());
		System.out.println(em);
		return "inbox-details";
	}

	@RequestMapping("/teammates")
	public String allTeamMember(@ModelAttribute("t") Employee e, ModelMap m) {
		List<Employee> l = (List<Employee>) iemployeerepo.findAll();
		System.out.println(l.remove(0));
		// m.addAttribute("admin", em);
		List<Integer> count = new ArrayList<>();
		for (int i = 1; i <= l.size(); i++)
			count.add(i);
		m.addAttribute("count", count);
		m.addAttribute("l", l);
		return "teammates";
	}

	@RequestMapping(value = { "/index" }, method = RequestMethod.POST)
	public String checkLogin(@ModelAttribute("t") Employee e, ModelMap m,@ModelAttribute("c") Certificate c,HttpSession session) {
		System.out.println(e);
		Employee em = iemployeerepo.findById(e.getEmplId()).get();
		// System.out.println("Hiii"+em);
		if (em != null) {
			if (e.getPassword().equals(em.getPassword())) {
				session.setAttribute("info", em.getEmplId());
				if (em.getRole().equalsIgnoreCase("ADMIN")) {
					 List<Certificate> l = new ArrayList<Certificate>();
					 l=iCertificateRepo.findAll();
					
					// System.out.println(l.remove(0));
					 m.addAttribute("admin", em);
					 m.addAttribute("l", l);

					// System.out.println("admin part:" + l);
					return "index";
				} else {
					m.addAttribute("emp", em);
					// System.out.println("user part:" + em);
					return "employee";
				}
			} else {
				m.addAttribute("msg", "Wrong Credentials.");
				return "welcome";
			}
		} else {
			m.addAttribute("msg", "User doesn't Exist.");
			return "welcome";
		}
	}

	@RequestMapping(value = "/cert/{id}", method = RequestMethod.GET)
	public String getCertificates(@PathVariable("id") String id, ModelMap m) {
		Employee e = employeeService.findById(id);
		m.addAttribute("emp", e);
		return "certificates";
	}

	@RequestMapping(value = "/addCert/{id}", method = RequestMethod.GET)
	public String getCertificates(@PathVariable("id") String id,
			@ModelAttribute("t") Certificate c, ModelMap m) {
		m.addAttribute("empid", id);
		return "addCertificate";
	}

	@RequestMapping(value = "/cert/{id}", method = RequestMethod.POST)
	public String updateCertificatesList(@PathVariable("id") String id,
			@ModelAttribute("t") EmpCertificate c, ModelMap m) {
		System.out.println("certificate to add: " + c);
		Employee e = employeeService.Update(id, c);
		System.out.println("Update:  " + e);
		m.addAttribute("emp", e);
		return "certificates";
	}
	
	//get type index
	@RequestMapping(value = { "/index" }, method = RequestMethod.GET)
	public String checkedLogin(@ModelAttribute("t") Employee e, ModelMap m,@ModelAttribute("c") Certificate c) {
//		Employee em = iemployeerepo.findById(e.getEmplId()).get();
		// System.out.println("Hiii"+em);
	
					 List<Certificate> l = new ArrayList<Certificate>();
					 l=iCertificateRepo.findAll();
					// System.out.println(l.remove(0));
//					 m.addAttribute("admin", em);
					 m.addAttribute("l", l);

					// System.out.println("admin part:" + l);
					return "index";
				
	}


}
