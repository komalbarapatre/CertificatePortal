package com.example.certificate.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

@Document(collection="Certificate")
public class Certificate {
	@Id
private String certificateName;
private String startDate;
private String endDate;
private int count;

public Certificate() {
	super();

}

public Certificate(String certificateName, String startDate, String endDate, int count) {
	super();
	this.certificateName = certificateName;
	this.startDate = startDate;
	this.endDate = endDate;
	this.count = count;
}

public String getCertificateName() {
	return certificateName;
}
public void setCertificateName(String certificateName) {
	this.certificateName = certificateName;
}
public String getStartDate() {
	return startDate;
}
public void setStartDate(String startDate) {
	this.startDate = startDate;
}
public String getEndDate() {
	return endDate;
}
public void setEndDate(String endDate) {
	this.endDate = endDate;
}
public int getCount() {
	return count;
}
public void setCount(int count) {
	this.count = count;
}

@Override
public String toString() {
	return "Certificate [certificateName=" + certificateName + ", startDate=" + startDate + ", endDate=" + endDate
			+", count="+count+ "]";
}
 


}
